#!/bin/bash

zip -r aws-tag-watch.zip index.js config.json node_modules/async node_modules/lodash
